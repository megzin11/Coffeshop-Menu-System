public class Latte extends Addons implements Drink{
  private   int Latteprice = 70;
    int quantity;
public Latte(int quantity){
    this.quantity=quantity;

}

    public void setLatteprice(int addonprice) {
        this.Latteprice += addonprice;
    }

    public int getLatteprice() {
        return Latteprice;
    }


    @Override
    public int Sum(int s) {
        subtotal=quantity*(s+getLatteprice());
        total=tax*subtotal+subtotal;
        return 0;

    }



}
