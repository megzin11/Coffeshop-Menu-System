public class Esspresso extends Addons implements Drink {
private int coffeeprice =50;
int quantity;
    public Esspresso(int quantity ){
        this.quantity=quantity;

    }


    public void setcoffeeprice(int coffeeprice) {
        this.coffeeprice = coffeeprice;
    }

    public int getCoffeeprice() {
        return coffeeprice;
    }


    @Override
    public int Sum(int s) {
        subtotal=quantity*(s+getCoffeeprice());
        total=tax*subtotal+subtotal;
        return 0;
    }

}
