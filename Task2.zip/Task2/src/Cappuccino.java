public class Cappuccino extends Addons implements Drink{

    private int Cappuccinoprice = 90;
    int quantity;

    public Cappuccino(    int quantity){
        this.quantity=quantity;
    }

    public void setCappuccinoprice(int addonprice) {
        Cappuccinoprice = addonprice;
    }

    public int getCappuccinoprice() {
        return Cappuccinoprice;
    }



    @Override
    public int Sum(int s) {
        subtotal=quantity*(s+getCappuccinoprice());
        total=tax*subtotal+subtotal;
        return 0;
    }



}
