import java.util.*;

public class Main {

    public static void main(String[] args) {
Esspresso e = new Esspresso(0);
Latte l =new Latte(0);
Cappuccino c =new Cappuccino(0);
        Scanner s=new Scanner(System.in);
        boolean flag=true;

            System.out.println("Welcome To StarX CoffeeShop\n");
            System.out.println("-------------------------------\n");
            System.out.println("Please Choose the required order by selecting the number and for add ons please select the 1st letter");
            System.out.println("Menu :\n");
            System.out.println("-------------------------------\n");
            System.out.println("Drinks : "+"\t\t\tAddons: ");
            System.out.println("1-Espresso " + e.getCoffeeprice()+"\t\tM:Milk "+e.Esspressomilk+"\t\tC:Cream "+e.Esspressocream+"\t\tL:Latte "+e.EsspressoLatte);
            System.out.println("2-Cappuccino " + c.getCappuccinoprice()+"\t\tM:Milk "+c.Capmilk+"\t\tC:Cream "+c.Capcream+"\t\tL:Latte "+c.CapLatte);
            System.out.println("3-Latte " + l.getLatteprice()+"\t\t\tM:Milk "+l.Lattemilk+"\t\tC:Cream "+l.Lattecream+"\t\tL:Latte "+l.LatteLatte);
            System.out.println("4-exit");
        while (flag) {
           int x = s.nextInt();
            if(x==1){
                System.out.println("how many?");
                e.quantity=s.nextInt();
                System.out.println(e.quantity+"cup of Espresso"+"\t\tAddons y/n?");

                String addon = s.next();
                 if(addon.equalsIgnoreCase("y"))
                     System.out.println("M : Milk  C:Cream  L:Latte"+"\t\tAddons y/n?");
                 else if (addon.equalsIgnoreCase("n")) {
                     break;
                 }
                addon=s.next();
                   if (addon.equalsIgnoreCase("M")){
                       System.out.println(e.quantity+"cup of Espresso"+"+ extra Milk");
                System.out.println("Esspresso : "+e.getCoffeeprice()+"\tExtra Milk : "+e.Esspressomilk);
                e.Sum(e.Esspressomilk);}
                   else if (addon.equalsIgnoreCase("C")){
                       System.out.println(c.quantity+" cup of Espresso"+"+ extra Cupcchino");
                       System.out.println("Esspresso : "+e.getCoffeeprice()+"\tExtra Milk : "+e.Esspressocream);
                       l.Sum(e.Esspressocream);}
                   else if (addon.equalsIgnoreCase("L")){
                       System.out.println(l.quantity+" cup of Espresso"+"+ extra Latte");
                       System.out.println("Esspresso : "+e.getCoffeeprice()+"\tExtra Latte : "+e.EsspressoLatte);
                       e.Sum(e.EsspressoLatte);}
                       System.out.println("Sub Total : "+e.subtotal);
                       System.out.println("Tax : "+e.tax);
                       System.out.println(" Total : "+e.total);

            } else if (x==2) {
                System.out.println("how many?");
                c.quantity=s.nextInt();
                System.out.println(c.quantity+"cup of Cappuchino"+"\t\tAddons y/n?");
                String addon = s.next();

                if(addon.equalsIgnoreCase("y"))
                    System.out.println("M : Milk  C:Cream  L:Latte"+"\t\tAddons y/n?");
                addon=s.next();
                  if (addon.equalsIgnoreCase("n")) {
                    break;
                }
                if (addon.equalsIgnoreCase("M")){
                    System.out.println(c.quantity+" cup of Espresso"+"+ extra Milk");
                System.out.println("Cappuchino : "+c.getCappuccinoprice()+"\tExtra Milk : "+c.Capmilk);
                c.Sum(c.Capmilk);}
                else if (addon.equalsIgnoreCase("C")){
                    System.out.println(c.quantity+" cup of Latte"+"+ extra Cupcchino");
                    System.out.println("Cappuchino : "+c.getCappuccinoprice()+"\tExtra Milk : "+c.Capcream);
                    l.Sum(c.Capcream);}
                else if (addon.equalsIgnoreCase("L")){
                    System.out.println(l.quantity+" cup of Latte"+"+ extra Latte");
                    System.out.println("Cappuchino : "+c.getCappuccinoprice()+"\tExtra Latte : "+c.CapLatte);
                    c.Sum(c.CapLatte);
                   } System.out.println("Sub Total : "+c.subtotal);
                System.out.println("Tax : "+c.tax);
                System.out.println(" Total : "+c.total);

            } else if (x==3) {
                System.out.println("how many?");
                l.quantity=s.nextInt();
                System.out.println(l.quantity+" cup of Latte"+"\t\tAddons y/n?");
                String addon = s.next();
                if(addon.equalsIgnoreCase("y"))
                    System.out.println("M : Milk  C:Cream  L:Latte"+"\t\tAddons y/n?");
                addon=s.next();
                  if (addon.equalsIgnoreCase("n")) {
                    break;
                }
                if (addon.equalsIgnoreCase("M")){
                    System.out.println(l.quantity+" cup of Latte"+"+ extra Milk");
                System.out.println("Esspresso : "+l.getLatteprice()+"\tExtra Milk : "+l.Lattemilk);
                l.Sum(l.Lattemilk);}
               else if (addon.equalsIgnoreCase("C")){
                    System.out.println(l.quantity+" cup of Latte"+"+ extra Cupcchino");
                    System.out.println("Esspresso : "+l.getLatteprice()+"\tExtra Milk : "+l.Lattecream);
                    l.Sum(l.Lattecream);}
               else if (addon.equalsIgnoreCase("L")){
                    System.out.println(l.quantity+" cup of Latte"+"+ extra Latte");
                    System.out.println("Latte : "+l.getLatteprice()+"\tExtra Latte : "+l.LatteLatte);
                    l.Sum(l.LatteLatte);
                   } System.out.println("Sub Total : "+l.subtotal);
                System.out.println("Tax : "+l.tax);
                System.out.println(" Total : "+l.total);

            } else if (x==4) {
                break;
            }



            System.out.println("Another order y/n");
            String addon = s.next();
            if(addon.equalsIgnoreCase("y")){
                System.out.println("enter the order no");
            x=s.nextInt();}
            else if(addon.equalsIgnoreCase("n"))
                break;

        }





    }
}
