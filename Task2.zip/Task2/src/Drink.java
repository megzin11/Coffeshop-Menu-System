interface Drink {

     abstract int Sum(int s);
}
