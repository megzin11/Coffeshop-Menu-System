abstract class Addons {
    int Esspressomilk=10;
    int Esspressocream=15;
    int EsspressoLatte=40;
    int Capmilk=10;
    int Capcream=20;
    int CapLatte=55;
    int Lattemilk=10;
    int Lattecream=25;
    int LatteLatte=60;
    double tax=0.14;
    double total=0;
    double subtotal=0;

}